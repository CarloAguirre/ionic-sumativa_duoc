import { Component } from '@angular/core'
import { Router } from '@angular/router'
import { SQLiteObject } from '@awesome-cordova-plugins/sqlite/ngx'

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss']
})
export class HomePage {
  segmentValue = 'misdatos'
  usuario = ''
  private database!: SQLiteObject

  constructor(private router: Router) {
    const navState = this.router.getCurrentNavigation()?.extras.state
    this.usuario = navState?.['usuario'] || ''
  }

  cambiarVista() {
    this.router.navigate([`/${this.segmentValue}`])
  }
}
